# Mixing codes for Kathy

Make sure code works with example data from FSC
