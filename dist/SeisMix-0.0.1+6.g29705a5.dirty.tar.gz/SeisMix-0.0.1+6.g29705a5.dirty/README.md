# Mixing codes for Kathy

Make sure code works with example data from FSC

Needs packages:
segyio: https://pypi.org/project/segyio/
